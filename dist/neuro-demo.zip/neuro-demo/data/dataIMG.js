event="img"
r1 = Math.random();
r2 = Math.random();
data=JSON.stringify({
	url: 'data/airport.jpg'
});

