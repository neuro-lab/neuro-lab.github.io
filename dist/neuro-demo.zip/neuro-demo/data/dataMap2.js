event="map2"
data=JSON.stringify({
	zoom: 6,
	center: [51.505, -0.09],
	series: [
		[50.505, -0.99],
		[52.000, -2.09],
		[51.505, -0.09],
	]
});

