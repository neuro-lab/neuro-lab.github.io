event="dataScattergeo"
data=JSON.stringify(
	{
        scope : 'europe',
        resolution : 50,
        locations : [ 'FRA', 'DEU', 'RUS', 'ESP' ],
        marker : {
            size : [ 20, 30, 15, 10 ],
        },
	}
);

