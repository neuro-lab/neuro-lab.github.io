k = 4*Math.random() + 9;
event="ppp"
data=JSON.stringify([
		{
			name: {en: 'Italy', ru: 'Италия'},
			y: 400 * k,
			//color: 'red',
		},
		{
			name: {en: 'Japan', ru: 'Япония'},
			y: 270 * k,
			//color: 'blue',
		},
		{
			name: {en: 'USA', ru: 'США'},
			y: 200 * k,
			color: '#69D1C5',
		}
	]);

