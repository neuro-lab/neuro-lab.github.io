event="counter"

MIN = 14851;
MAX = 92456;

if (typeof r == "undefined")
	r = MIN;
if (r > MAX)
	r = MIN;
r++;
data=r;
