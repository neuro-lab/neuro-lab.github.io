event="map"
data=JSON.stringify({
	zoom: 1,
	center: [51.505, -0.09],
	series: [
		[50.505, -0.99],
		[62.000, -20.09],
		[1.505, -90.09],
	]
});

