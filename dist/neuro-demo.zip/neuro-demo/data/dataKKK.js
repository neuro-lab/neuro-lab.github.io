event="kkk"
data="My message " + Math.random() + 'ABC'

