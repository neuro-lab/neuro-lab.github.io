class BarChartHorizontal extends AbstractBarChart {
	constructor() {
		super({
			orientation: 'h',
		});
	}
}
