class BarChartVertical extends AbstractBarChart {
	constructor() {
		super({
			orientation: 'v',
		});
	}
}
